from PIL import Image, ImageDraw
from pathlib import Path

base = Path(r"c:/Users/82109/Desktop/재혁")
for size in (192, 512):
    img = Image.new("RGBA", (size, size), (246, 241, 238, 255))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((12, 12, size - 12, size - 12), radius=size // 10, fill=(29, 23, 21, 255))
    d.rounded_rectangle((size // 6, size // 6, size - size // 6, size - size // 6), radius=size // 12, fill=(184, 139, 99, 255))
    d.text((size // 2, size // 2), "💍", anchor="mm", fill=(255, 255, 255, 255), font=None)
    img.save(base / f"icon-{size}.png")
    print(f"created {base / f'icon-{size}.png'}")
