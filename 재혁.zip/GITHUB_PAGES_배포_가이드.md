# GitHub Pages 공개 배포 가이드

## 1. GitHub 저장소 준비

1. GitHub에 새 저장소를 생성합니다.
2. 이 폴더 안의 모든 파일을 업로드합니다.
3. 저장소 루트에 다음 파일이 있어야 합니다.
   - index.html
   - 결혼준비_비용_대시보드_모바일_v2.html
   - 배포용_모바일/index.html
   - 배포용_모바일/manifest.json
   - 배포용_모바일/sw.js
   - icon-192.png
   - icon-512.png

## 2. GitHub Pages 활성화

1. GitHub 저장소에서 Settings → Pages 로 이동합니다.
2. Source를 "Deploy from a branch" 로 선택합니다.
3. Branch는 "main" 또는 "master" 를 선택합니다.
4. 폴더는 "/ (root)" 로 선택합니다.
5. Save 합니다.

## 3. 공개 URL 확인

배포가 완료되면 아래 형태의 URL로 접속할 수 있습니다.

https://[github-username].github.io/[repository-name]/

예시:

https://kimhyejin.github.io/wedding-budget/


이 주소는 루트 index.html 로 이동하고, 최종적으로 배포용 모바일 페이지로 연결됩니다.

## 4. 모바일에서 열기

공개 URL을 휴대폰 브라우저에 붙여넣으면 바로 열립니다.

- 기본 진입점: https://[github-username].github.io/[repository-name]/
- 직접 페이지: https://[github-username].github.io/[repository-name]/배포용_모바일/index.html

## 5. 주의사항

- 다른 네트워크에서 접속 가능
- 진짜 공개 URL이므로 GitHub 계정이 필요함
- 브라우저 로컬 저장소는 휴대폰별로 유지됨
- 데이터는 브라우저 내부 localStorage 에 저장됨

## 6. 검증 결과

로컬 테스트에서 총액 97,867,300원, 항목 수 20개가 정상 출력됨이 확인된 상태입니다.
